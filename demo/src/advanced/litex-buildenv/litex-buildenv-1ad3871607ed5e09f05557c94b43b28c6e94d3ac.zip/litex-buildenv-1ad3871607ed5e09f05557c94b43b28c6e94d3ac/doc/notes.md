
# Setting up the environment

[This info has moved to the LiteX Build Environment Wiki's Environment page](https://github.com/timvideos/litex-buildenv/wiki/Environment#setting-up-the-environment)

# Random Comments

[This info has moved to the LiteX Build Environment Wiki's Glossary page](https://github.com/timvideos/litex-buildenv/wiki/Glossary)

