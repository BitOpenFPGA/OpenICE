#!/bin/bash

mkdir -p ~/.conda
chmod 0000 ~/.conda
