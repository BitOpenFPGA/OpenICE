from gateware.encoder.core import EncoderDMAReader, EncoderBuffer, Encoder
