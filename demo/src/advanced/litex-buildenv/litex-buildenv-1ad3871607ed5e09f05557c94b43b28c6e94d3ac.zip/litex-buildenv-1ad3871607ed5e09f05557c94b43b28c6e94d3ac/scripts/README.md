Documentation for using these scripts can be found in the
[getting-started.md](/getting-started.md) file.

Description of what these scripts do can be found in
[docs/notes.md](docs/notes.md) file.
