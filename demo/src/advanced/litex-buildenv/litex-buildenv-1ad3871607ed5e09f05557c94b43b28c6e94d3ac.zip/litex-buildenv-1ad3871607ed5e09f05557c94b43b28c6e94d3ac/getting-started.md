For project description and information see the project [README.md](/) file.

The [getting started document now lives in the LiteX Build Environment Wiki](https://github.com/timvideos/litex-buildenv/wiki/Getting-Started).
