#ifndef __BIST_H
#define __BIST_H

void bist_test(void);

#endif /* __BIST_H */
