#ifndef __UPTIME_H
#define __UPTIME_H

void uptime_service(void);
int uptime(void);

void uptime_print(void);
const char* uptime_str(void);

#endif /* __CONFIG_H */
