#ifndef __FLASH_H
#define __FLASH_H

void flash_test(void);

#endif /* __FLASH_H */
