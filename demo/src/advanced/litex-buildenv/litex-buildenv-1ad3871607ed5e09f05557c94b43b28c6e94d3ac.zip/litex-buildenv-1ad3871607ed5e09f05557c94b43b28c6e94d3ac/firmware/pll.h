#ifndef __PLL_H
#define __PLL_H

void pll_config_for_clock(int freq);
void pll_dump(void);

#endif
