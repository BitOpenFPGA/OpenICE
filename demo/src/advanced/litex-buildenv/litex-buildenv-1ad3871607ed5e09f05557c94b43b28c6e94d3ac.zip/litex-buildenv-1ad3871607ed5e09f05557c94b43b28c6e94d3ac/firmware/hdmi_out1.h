#include <generated/csr.h>

#ifdef CSR_HDMI_OUT1_I2C_W_ADDR
void hdmi_out1_i2c_init(void);
void hdmi_out1_print_edid(void);
#endif
