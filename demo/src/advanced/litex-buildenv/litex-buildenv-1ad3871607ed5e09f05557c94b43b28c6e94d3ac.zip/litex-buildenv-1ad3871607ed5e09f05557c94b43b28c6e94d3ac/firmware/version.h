#ifndef __VERSION_H
#define __VERSION_H

void print_board_dna(void);
void print_board_mac(void);
void print_version(void);

#endif // __VERSION_H
