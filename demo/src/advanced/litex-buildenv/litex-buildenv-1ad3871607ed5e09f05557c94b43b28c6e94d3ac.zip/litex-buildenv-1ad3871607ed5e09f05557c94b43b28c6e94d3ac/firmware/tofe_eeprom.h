#include <generated/csr.h>
#ifdef CSR_TOFE_I2C_W_ADDR

void tofe_eeprom_i2c_init(void);
void tofe_eeprom_dump(void);

#endif
