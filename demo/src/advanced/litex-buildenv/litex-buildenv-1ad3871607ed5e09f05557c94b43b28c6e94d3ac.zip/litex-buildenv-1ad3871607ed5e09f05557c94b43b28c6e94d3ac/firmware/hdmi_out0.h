#include <generated/csr.h>

#ifdef CSR_HDMI_OUT0_I2C_W_ADDR
void hdmi_out0_i2c_init(void);
void hdmi_out0_print_edid(void);
#endif
