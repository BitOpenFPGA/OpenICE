from litex.boards.platforms import sim
from litex.boards.platforms.sim import *
__all__ = ['SimPins', 'Platform']
