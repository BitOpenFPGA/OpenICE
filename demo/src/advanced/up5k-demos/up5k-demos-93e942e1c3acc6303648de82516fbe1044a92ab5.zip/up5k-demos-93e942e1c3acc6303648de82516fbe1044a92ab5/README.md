# ice40 demos mostly for the UltraPlus

This is a project of mine to develop cool demos for the ice40 FPGAs 
using the icoTC toolchain (Yosys, arachne-pnr and icestorm).

At the moment there is a working port of the MIST NES core, see the nes 
folder for more information.

I'm going to work on a Gameboy core at some point but first that will 
need a CPU in Verilog instead of VHDL.
