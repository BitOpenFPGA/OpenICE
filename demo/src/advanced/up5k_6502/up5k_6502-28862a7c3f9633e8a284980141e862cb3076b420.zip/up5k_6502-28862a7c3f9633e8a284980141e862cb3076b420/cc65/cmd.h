/*
 * cmd.c - process commands
 * 03-06-19 E. Brombaugh
 */

#ifndef __cmd__
#define __cmd__

void cmd_init(void);
void cmd_do(void);

#endif
