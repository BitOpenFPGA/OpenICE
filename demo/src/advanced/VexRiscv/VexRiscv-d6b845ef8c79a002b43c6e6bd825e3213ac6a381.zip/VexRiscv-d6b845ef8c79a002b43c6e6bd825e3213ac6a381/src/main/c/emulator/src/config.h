#ifndef CONFIG_H
#define CONFIG_H

#ifndef OS_CALL
#define OS_CALL 0xC0000000
#endif

#ifndef DTB
#define DTB 0xC3000000
#endif

#endif
