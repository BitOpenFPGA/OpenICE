#! /bin/bash

echo "preempted :(" | mail -s "VexRiscv cloud" charles.papon.90@gmail.com -A /home/spinalvm/run.txt
sleep 10
