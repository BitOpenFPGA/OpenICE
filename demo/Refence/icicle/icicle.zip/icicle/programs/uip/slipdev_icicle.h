#ifndef SLIPDEV_ICICLE_H
#define SLIPDEV_PICOSOH_H

void slipdev_icicle_init(void);

#endif
